local ParticleSystem = {}
ParticleSystem.__index = ParticleSystem

function ParticleSystem.new(x, y)
    local self = setmetatable({}, ParticleSystem)
    self.particles = {}
    self.x = x
    self.y = y
    self.emissionRate = 30
    self.lifetime = {1, 3}
    return self
end

function ParticleSystem:emit()
    for i = 1, self.emissionRate do
        table.insert(self.particles, {
            x = self.x,
            y = self.y,
            lifetime = math.random(self.lifetime[1], self.lifetime[2]),
            age = 0,
            size = math.random(5, 10),
            speedX = math.random(-100, 100),
            speedY = math.random(-100, 100)
        })
    end
end

function ParticleSystem:update(dt)
    for i = #self.particles, 1, -1 do
        local p = self.particles[i]
        p.age = p.age + dt
        if p.age > p.lifetime then
            table.remove(self.particles, i)
        else
            p.x = p.x + p.speedX * dt
            p.y = p.y + p.speedY * dt
        end
    end
end

function ParticleSystem:draw()
    for _, p in ipairs(self.particles) do
        local alpha = 1 - (p.age / p.lifetime)
        love.graphics.setColor(1, 1, 1, alpha)
        love.graphics.circle("fill", p.x, p.y, p.size)
    end
    love.graphics.setColor(1, 1, 1, 1)
end

return ParticleSystem