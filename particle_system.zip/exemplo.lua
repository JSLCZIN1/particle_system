-- EXEMPLO

local ParticleSystem = require("lib.particle_system") -- Importa a biblioteca 
local ps

function love.load()
    ps = ParticleSystem.new(0, 0) -- Cria um novo sistema de partículas
end

function love.mousepressed(x, y, button, istouch, presses)
    if button == 1 then
        ps.x = x -- Define a posição do sistema de partículas x
        ps.y = y  -- Define a posição do sistema de partículas y
        ps:emit() -- Emite partículas
    end
end

function love.update(dt)
    ps:update(dt) -- Atualiza o sistema de partículas
end

function love.draw()
    love.graphics.clear() -- Limpa a tela
    ps:draw() -- Desenha o sistema de partículas
end